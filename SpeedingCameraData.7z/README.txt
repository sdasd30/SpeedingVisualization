This csv has 11 columns to consider. From left to right:

Camera: What is the street address of the camera? 
Timestamp: How many months since this camera first started recording speeding tickets?
Year: What year is this row referring to?
Month: What month is this row referring to?
Total Offenses: How many offenses in total has this camera seen, as of this current time. This is cumulative
Total Unique Offenders: How many unique license plates has this camera seen in total, as of this current time stamp. This is cumulative.
New Offenders This Month: How many license plates has this camera seen this month that it has never seen before?
Repeat Offenders: How many of the license plates this camera saw this month has this camera seen before?
Repeat Offenders Within The Year: How many of the license plates this camera saw this month this camera has seen before within the past 12 months?
Repeat Offenders Within Past 6 Months: How many of the license plates this camera saw this month this camera has seen before within the past 6 months?
Repeat Offenders Within The Month: How many license plates this camera that this camera has seen before within the month? (The most egregious of speeders)


For each camera, the data starts when the camera gets its first speeding ticket, and ends at May, 2018. 
If you want the total number of offenses/repeat offenders, you will want to pull 2018 for the year, and 5 for the month for each camera.

